"""passlib - suite of password hashing & generation routines"""

__version__ = '1.7.4'
